A measurement set interface to perform phase rotation, originally written by Cyril Tasse

