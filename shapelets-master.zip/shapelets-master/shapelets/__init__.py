"""
A module interface to shapelet functions
"""

__version__ = '0.2' #this needs to be kept up to date with setup.py

import decomp, fileio, img, measure, shapelet

